REN OS GENESIS — STANDALONE EDITION

1. Unzip the folder.
2. Double-click index.html.
3. Choose Chrome, Edge, Firefox, or Safari.
4. Your entries save automatically in that browser on that computer.
5. Use Export Backup before moving to another browser or computer.
6. Use Import Backup to restore your data.

This version needs no GitHub, Codespaces, server, or internet connection.
